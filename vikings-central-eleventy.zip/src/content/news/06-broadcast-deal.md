---
title: "What the new local broadcast deal means for how you'll watch this season"
date: 2026-07-12
date_label: "JUL 12"
category: "Business"
tag_class: "business"
byline: "Filed by the business desk"
horns: 41
description: "A rundown of the carriage changes fans should know about before kickoff weekend arrives."
---

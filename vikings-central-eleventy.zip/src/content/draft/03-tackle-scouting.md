---
title: "The tackle prospect flying under the radar right now"
date: 2026-07-09
date_label: "JUL 09"
category: "Scouting Notes"
tag_class: "business"
byline: "Filed by the draft desk"
horns: 63
description: "Long arms, raw anchor technique — the kind of developmental tackle who profiles as a year-two starter more than an immediate plug-in."
---

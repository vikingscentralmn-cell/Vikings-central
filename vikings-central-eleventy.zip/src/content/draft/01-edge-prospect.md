---
title: "The pass rusher who'd reshape the front seven, if the board falls right"
date: 2026-07-19
date_label: "JUL 19"
category: "Big Board"
tag_class: "roster"
byline: "Filed by the draft desk"
horns: 96
description: "An explosive first step and real bend off the edge — the kind of prospect that changes how a defensive coordinator can scheme on third down."
---

---
title: "A press-man corner worth tracking all season"
date: 2026-07-02
date_label: "JUL 02"
category: "Early Buzz"
tag_class: "roster"
byline: "Filed by the draft desk"
horns: 58
description: "Physical tools are ahead of instincts right now, which usually means one strong college season away from being a true Day 2 riser."
---

---
title: "Locking up a special-teams piece before the market could set his price"
date: 2026-07-16
date_label: "JUL 16"
category: "Re-signing"
tag_class: "roster"
byline: "Filed by the roster desk"
horns: 88
description: "Retaining him now, before camp performances start driving other teams' offers, tells you how the front office is valuing consistency over upside this summer."
---

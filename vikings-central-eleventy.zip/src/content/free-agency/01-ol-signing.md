---
title: "Why the interior O-line move matters more than the depth chart suggests"
date: 2026-07-20
date_label: "JUL 20"
category: "Signing"
tag_class: "business"
byline: "Filed by the roster desk"
horns: 103
description: "On paper it's a camp-body signing. In practice, it plugs the exact gap that showed up twice in spring reps — and buys the staff real flexibility once pads come on."
---

const fs = require("fs");
const path = require("path");
module.exports = {
  logoB64: fs.readFileSync(path.join(__dirname, "logo_b64.txt"), "utf8").trim(),
  brettB64: fs.readFileSync(path.join(__dirname, "brett_b64.txt"), "utf8").trim()
};

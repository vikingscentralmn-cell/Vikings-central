module.exports = function (eleventyConfig) {
  eleventyConfig.addCollection("news", function (collectionApi) {
    return collectionApi.getFilteredByGlob("src/content/news/*.md").sort((a, b) => b.date - a.date);
  });
  eleventyConfig.addCollection("freeAgency", function (collectionApi) {
    return collectionApi.getFilteredByGlob("src/content/free-agency/*.md").sort((a, b) => b.date - a.date);
  });
  eleventyConfig.addCollection("draft", function (collectionApi) {
    return collectionApi.getFilteredByGlob("src/content/draft/*.md").sort((a, b) => b.date - a.date);
  });
  eleventyConfig.addCollection("opinion", function (collectionApi) {
    return collectionApi.getFilteredByGlob("src/content/opinion/*.md").sort((a, b) => b.date - a.date);
  });
  eleventyConfig.addCollection("notebook", function (collectionApi) {
    return collectionApi.getFilteredByGlob("src/content/notebook/*.md").sort((a, b) => b.date - a.date);
  });

  eleventyConfig.addPassthroughCopy("admin");

  return {
    dir: {
      input: "src",
      includes: "_includes",
      data: "_data",
      output: "_site"
    }
  };
};
